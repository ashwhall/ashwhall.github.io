- Jupyter Wrapper -

An unofficial wrapper which provides a GUI for Jupyter Notebook server.

Installation:
1. You must already have Jupyter Notebook installed and added to your 
   environment %PATH% variable, such that the server can be started by
   typing 'jupyter notebook' (without the quotes) from anywhere in cmd.
2. Extract JupyterWrapper.exe
3. Run it and select your Jupyter working directory


- This application has been developed entirely separately from the 
Jupyter team, and as such Jupyter notebook must be downloaded and from
http://jupyter.org/